package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Min;

import org.springframework.stereotype.Component;
import org.springmodules.validation.bean.conf.loader.annotation.handler.Email;
import org.springmodules.validation.bean.conf.loader.annotation.handler.Length;
import org.springmodules.validation.bean.conf.loader.annotation.handler.NotBlank;
import org.springmodules.validation.bean.conf.loader.annotation.handler.NotNull;

@Entity
@Component
public class Trainee {
	@Id
	@GeneratedValue(generator="se",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="se",sequenceName="traseq",initialValue=100,allocationSize=1)
private int tid;
@NotBlank(message="Name must be provided")
private String username;
@NotBlank(message="Password should not be empty")
@Length(min=8, max=20,message="password length >=8 and <20")
private String password;
@NotNull(message="please provide age")
@Min(value=18,message="age should be >18")
private Integer age;
@NotBlank(message="Email must be provided")
@Email(message="Invalid email id")
private String email;
private String gender;
public Trainee() {
	// TODO Auto-generated constructor stub
}
public int getTid() {
	return tid;
}
public void setTid(int tid) {
	this.tid = tid;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Integer getAge() {
	return age;
}
public void setAge(Integer age) {
	this.age = age;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
@Override
public String toString() {
	return "Trainee [pid=" + tid + ", username=" + username + ", password=" + password + ", age=" + age + ", email="
			+ email + ", gender=" + gender + "]";
}


}
